import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * @author Eric Zhou
 */

public class GlossaryTest {

    /*
     * Tests of readGlossary
     */

    /*
     * testing readGlossary with two terms, routine test
     **/
    @Test
    public void readGlossary_twoterms() {
        final String fileName = "testfile.txt";

        SimpleWriter writer = new SimpleWriter1L(fileName);
        writer.println("term1");
        writer.println("This is a definition.");
        writer.println("It spans two lines.");
        writer.println();
        writer.println("term2");
        writer.println("Second definition.");
        writer.println();
        writer.close();

        SimpleReader reader = new SimpleReader1L(fileName);
        reader.close();

        Map<String, String> actual = Glossary.readGlossary(fileName);

        Map<String, String> expected = new Map1L<>();
        expected.add("term1", "This is a definition. It spans two lines.");
        expected.add("term2", "Second definition.");

        assertEquals(expected, actual);
    }

    /*
     * testing readGlossary with two line definition, boundary test
     **/
    @Test
    public void readGlossary_twolinedef() {
        final String fileName = "testfile.txt";

        SimpleWriter writer = new SimpleWriter1L(fileName);
        writer.println("term1");
        writer.println("This is a definition.");
        writer.println("It spans two lines.");
        writer.println();
        writer.println("term2");
        writer.println("Second definition.");
        writer.println();
        writer.close();

        SimpleReader reader = new SimpleReader1L(fileName);
        reader.close();

        Map<String, String> actual = Glossary.readGlossary(fileName);

        Map<String, String> expected = new Map1L<>();
        expected.add("term1", "This is a definition. It spans two lines.");
        expected.add("term2", "Second definition.");

        assertEquals(expected, actual);
    }

    /*
     * testing readGlossary with five terms and with one or two line definition,
     * large number test
     **/
    @Test
    public void readGlossary_fiveterms() {
        final String fileName = "testfile.txt";

        SimpleWriter writer = new SimpleWriter1L(fileName);
        writer.println("Term1");
        writer.println("Definition of term one.");
        writer.println();
        writer.println("Term2");
        writer.println("Definition of term two.");
        writer.println("Continued on second line.");
        writer.println();
        writer.println("Term3");
        writer.println("Definition three.");
        writer.println();
        writer.println("Term4");
        writer.println("Fourth term definition line.");
        writer.println();
        writer.println("Term5");
        writer.println("Fifth.");
        writer.println();
        writer.close();

        Map<String, String> actual = Glossary.readGlossary(fileName);

        Map<String, String> expected = new Map1L<>();
        expected.add("Term1", "Definition of term one.");
        expected.add("Term2", "Definition of term two. Continued on second line.");
        expected.add("Term3", "Definition three.");
        expected.add("Term4", "Fourth term definition line.");
        expected.add("Term5", "Fifth.");

        assertEquals(expected, actual);
    }

    /*
     * Tests of sort
     */

    /*
     * testing sort with a sequence needed to be sorted, routine test
     **/
    @Test
    public void sort_neeededtobesorted() {
        Sequence<String> seq = new Sequence1L<>();
        seq.add(0, "banana");
        seq.add(1, "apple");
        seq.add(2, "grape");
        seq.add(3, "watermelon");
        seq.add(4, "cherry");

        Glossary.sort(seq);

        Sequence<String> expected = new Sequence1L<>();
        expected.add(0, "apple");
        expected.add(1, "banana");
        expected.add(2, "cherry");
        expected.add(3, "grape");
        expected.add(4, "watermelon");

        assertEquals(expected, seq);
    }

    /*
     * testing sort with a sequence with nice order, boundary test
     **/
    @Test
    public void testSort_AlreadySorted() {
        Sequence<String> seq = new Sequence1L<>();
        seq.add(0, "apple");
        seq.add(1, "banana");
        seq.add(2, "cherry");
        seq.add(3, "grape");
        seq.add(4, "watermelon");

        Glossary.sort(seq);

        Sequence<String> expected = new Sequence1L<>();
        expected.add(0, "apple");
        expected.add(1, "banana");
        expected.add(2, "cherry");
        expected.add(3, "grape");
        expected.add(4, "watermelon");

        assertEquals(expected, seq);
    }

    /*
     * testing sort with a sequence with nice order, boundary test
     **/
    @Test
    public void testSort_twoapple() {
        Sequence<String> seq = new Sequence1L<>();
        seq.add(0, "banana");
        seq.add(1, "apple");
        seq.add(2, "apple");
        seq.add(3, "grape");

        Glossary.sort(seq);

        Sequence<String> expected = new Sequence1L<>();
        expected.add(0, "apple");
        expected.add(1, "apple");
        expected.add(2, "banana");
        expected.add(3, "grape");

        assertEquals(expected, seq);
    }

    /*
     * Tests of addLinks
     */

    /*
     * testing addLinks with one term needed to be linked, routine test
     **/
    @Test
    public void addLinks_oneLink() {
        String def = "The apple is red.";

        Sequence<String> terms = new Sequence1L<>();
        terms.add(0, "apple");

        String actual = Glossary.addLinks(def, terms);

        String expected = "The <a href=\"apple.html\"><b><i>apple</i></b></a> is red.";

        assertEquals(expected, actual);
    }

    /*
     * testing addLinks with two terms needed to be linked, routine test
     **/
    @Test
    public void addLinks_twoLinks() {
        String def = "I like apple and banana.";

        Sequence<String> terms = new Sequence1L<>();
        terms.add(0, "apple");
        terms.add(1, "banana");

        String actual = Glossary.addLinks(def, terms);

        String expected = "I like <a href=\"apple.html\"><b><i>apple</i></b></a> "
                + "and <a href=\"banana.html\"><b><i>banana</i></b></a>.";

        assertEquals(expected, actual);
    }

    /*
     * testing addLinks with no term needed to be linked, boundary test
     **/
    @Test
    public void addLinks_noLink() {
        String def = "The sky is blue.";
        Sequence<String> terms = new Sequence1L<>();

        String actual = Glossary.addLinks(def, terms);
        String expected = "The sky is blue.";

        assertEquals(expected, actual);
    }

    /*
     * Tests of nextWordOrSeparator
     */

    /*
     * testing nextWordOrSeparator with start with word, boundary test
     **/
    @Test
    public void nextWordOrSeparator_Word() {
        String text = "apple pie!";
        int position = 0;

        Set<Character> separators = new Set1L<>();
        separators.add(' ');
        separators.add('!');

        String actual = Glossary.nextWordOrSeparator(text, position, separators);
        String expected = "apple";

        assertEquals(expected, actual);
    }

    /*
     * testing nextWordOrSeparator with start with separator, boundary test
     **/
    @Test
    public void nextWordOrSeparator_Separator() {
        String text = "hello  world";
        int position = 5;

        Set<Character> separators = new Set1L<>();
        separators.add(' ');

        String actual = Glossary.nextWordOrSeparator(text, position, separators);
        String expected = "  ";

        assertEquals(expected, actual);
    }

    /*
     * testing nextWordOrSeparator with start with word in middle, routine test
     **/
    @Test
    public void nextWordOrSeparator_Middle() {
        String text = "Hi,there!";
        int position = 3;

        Set<Character> separators = new Set1L<>();
        separators.add(' ');
        separators.add(',');
        separators.add('!');

        String actual = Glossary.nextWordOrSeparator(text, position, separators);
        String expected = "there";

        assertEquals(expected, actual);
    }

    /*
     * Tests of writeIndexPage
     */

    /*
     * testing writeIndexPage with two terms, routine test
     **/
    @Test
    public void testWriteIndexPage_twoterms() {
        final String folder = "test";
        final String filePath = folder + "/index.html";

        Sequence<String> terms = new Sequence1L<>();
        terms.add(0, "apple");
        terms.add(1, "banana");

        Glossary.writeIndexPage(terms, folder);

        SimpleReader in = new SimpleReader1L(filePath);
        assertEquals("<html><head><title>Glossary</title></head><body>", in.nextLine());
        assertEquals("<h2>Glossary Index</h2>", in.nextLine());
        assertEquals("<ul>", in.nextLine());
        assertEquals("<li><a href=\"apple.html\">apple</a></li>", in.nextLine());
        assertEquals("<li><a href=\"banana.html\">banana</a></li>", in.nextLine());
        assertEquals("</ul>", in.nextLine());
        assertEquals("</body></html>", in.nextLine());
        in.close();
    }

    /*
     * testing writeIndexPage with three terms, routine test
     **/
    @Test
    public void testWriteIndexPage_threeterms() {
        final String folder = "test";
        final String filePath = folder + "/index.html";

        Sequence<String> terms = new Sequence1L<>();
        terms.add(0, "apple");
        terms.add(1, "banana");
        terms.add(2, "cherry");

        Glossary.writeIndexPage(terms, folder);

        SimpleReader in = new SimpleReader1L(filePath);
        assertEquals("<html><head><title>Glossary</title></head><body>", in.nextLine());
        assertEquals("<h2>Glossary Index</h2>", in.nextLine());
        assertEquals("<ul>", in.nextLine());
        assertEquals("<li><a href=\"apple.html\">apple</a></li>", in.nextLine());
        assertEquals("<li><a href=\"banana.html\">banana</a></li>", in.nextLine());
        assertEquals("<li><a href=\"cherry.html\">cherry</a></li>", in.nextLine());
        assertEquals("</ul>", in.nextLine());
        assertEquals("</body></html>", in.nextLine());
        in.close();
    }

    /*
     * Tests of writeTermPage
     */

    /*
     * testing writeTermPage with apple, routine test
     **/
    @Test
    public void writeTermPage_apple() {
        final String folder = "test";
        final String term = "apple";
        final String filePath = folder + "/" + term + ".html";

        String def = "apple is red.";

        Sequence<String> terms = new Sequence1L<>();
        terms.add(0, "apple");

        Glossary.writeTermPage(term, def, terms, folder);

        SimpleReader in = new SimpleReader1L(filePath);

        assertEquals("<html><head><title>apple</title></head><body>", in.nextLine());
        assertEquals("<h2><b><i><span style=\"color:red\">apple</span></i></b></h2>",
                in.nextLine());
        assertEquals("<p><a href=\"apple.html\"><b><i>apple</i></b></a> is red.</p>",
                in.nextLine());
        assertEquals("<p><a href=\"index.html\">Back to index</a></p>", in.nextLine());
        assertEquals("</body></html>", in.nextLine());

        in.close();
    }

    /*
     * testing writeTermPage with banana, routine test
     **/
    @Test
    public void testWriteTermPage_Banana() {
        final String folder = "test";
        final String term = "banana";
        final String filePath = folder + "/" + term + ".html";

        String def = "banana is yellow";

        Sequence<String> terms = new Sequence1L<>();
        terms.add(0, "banana");

        Glossary.writeTermPage(term, def, terms, folder);

        SimpleReader in = new SimpleReader1L(filePath);

        assertEquals("<html><head><title>banana</title></head><body>", in.nextLine());
        assertEquals("<h2><b><i><span style=\"color:red\">banana</span></i></b></h2>",
                in.nextLine());
        assertEquals("<p><a href=\"banana.html\"><b><i>banana</i></b></a> is yellow</p>",
                in.nextLine());
        assertEquals("<p><a href=\"index.html\">Back to index</a></p>", in.nextLine());
        assertEquals("</body></html>", in.nextLine());

        in.close();
    }

}
