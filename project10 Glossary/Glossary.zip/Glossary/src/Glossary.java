import components.map.Map;
import components.map.Map.Pair;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Write a HTML page and make a glossary.
 *
 * @author Eric Zhou
 *
 */
public final class Glossary {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Glossary() {
    }

    /**
     * get all the terms and definition.
     *
     * @param inputFile
     *            the file inputed by the user
     * @return the final map
     *
     */
    public static Map<String, String> readGlossary(String inputFile) {
        Map<String, String> m = new Map1L<>();
        SimpleReader file = new SimpleReader1L(inputFile);

        while (!file.atEOS()) { //check whether at the end of the file
            String term = file.nextLine();

            String definition = "";
            String line = "";
            do {
                line = file.nextLine();
                definition = definition.concat(" ").concat(line);
            } while (!line.equals("") && !file.atEOS());
            //check next line is definition or the end

            m.add(term, definition.trim());

        }

        file.close();
        return m;
    }

    /**
     * sort the terms by alphabetical order.
     *
     * @param seq
     *            the sequence needed to be sorted
     */
    public static void sort(Sequence<String> seq) {
        for (int i = 0; i < seq.length(); i++) {
            for (int j = i + 1; j < seq.length(); j++) {
                if (seq.entry(j).compareTo(seq.entry(i)) < 0) { //compare the element
                    String temp = seq.remove(j);
                    seq.add(i, temp);
                }
            }
        }
    }

    /**
     *
     * @param terms
     *            all the terms needed to be added
     * @param folder
     *            the aim folder provided by the user
     */
    public static void writeIndexPage(Sequence<String> terms, String folder) {
        SimpleWriter out = new SimpleWriter1L(folder + "/index.html");

        out.println("<html><head><title>Glossary</title></head><body>");
        out.println("<h2>Glossary Index</h2>");
        out.println("<ul>");
        for (int i = 0; i < terms.length(); i++) { //output all the terms
            String term = terms.entry(i);
            out.println("<li><a href=\"" + term + ".html\">" + term + "</a></li>");
        }
        out.println("</ul>");
        out.println("</body></html>");

        out.close();
    }

    /**
     *
     * @param term
     *            the specific term
     * @param def
     *            the definition of the term
     * @param terms
     *            the sequence of the terms with definition
     * @param folder
     *            the output folder
     */
    public static void writeTermPage(String term, String def, Sequence<String> terms,
            String folder) {
        SimpleWriter out = new SimpleWriter1L(folder + "/" + term + ".html");

        out.println("<html><head><title>" + term + "</title></head><body>");
        out.println(
                "<h2><b><i><span style=\"color:red\">" + term + "</span></i></b></h2>");
        out.println("<p>" + addLinks(def, terms) + "</p>");
        out.println("<p><a href=\"index.html\">Back to index</a></p>");
        out.println("</body></html>");

        out.close();
    }

    /**
     *
     * @param def
     *            the definition of term
     * @param terms
     *            the sequence of terms
     * @return the term with link
     */
    public static String addLinks(String def, Sequence<String> terms) {
        String result = "";
        final String separatorChars = " \t\n\r,.:;!?()";
        Set<Character> separators = new Set1L<>();
        for (int i = 0; i < separatorChars.length(); i++) {
            separators.add(separatorChars.charAt(i));
        }

        int position = 0;
        while (position < def.length()) {
            String candi = nextWordOrSeparator(def, position, separators);

            boolean linked = false;
            int i = 0;
            while (i < terms.length()) {
                String t = terms.entry(i);
                if (!linked && candi.equals(t)) { //check whether need to add link
                    result += "<a href=\"" + t + ".html\"><b><i>" + t + "</i></b></a>";
                    linked = true;
                }
                i++;
            }

            if (!linked) {
                result = result.concat(candi);
            }

            position += candi.length();
        }

        return result;
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *  text[position, position + |nextWordOrSeparator|)  and
     *  if entries(text[position, position + 1)) intersection separators = {}
     *    then
     *      entries(nextWordOrSeparator) intersection separators = {}  and
     *        (position + |nextWordOrSeparator| = |text|  or
     *         entries(text[position, position + |nextWordOrSeparator| + 1))
     *           intersection separators /= {})
     *  else
     *      entries(nextWordOrSeparator) is subset of separators  and
     *        (position + |nextWordOrSeparator| = |text|  or
     *         entries(text[position, position + |nextWordOrSeparator| + 1))
     *           is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        String value = "";
        int index = position;
        if (separators.contains(text.charAt(position))) { //check the value
            while (index < text.length() && separators.contains(text.charAt(index))) {
                index++;
            }
        } else { //if the value is not separators
            while (index < text.length() && !separators.contains(text.charAt(index))) {
                index++;
            }
        }
        value = text.substring(position, index);
        return value;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter input file name: "); //ask for the file
        String inputFile = in.nextLine();

        out.print("Enter output folder name: ");
        String outputFolder = in.nextLine();

        Map<String, String> glossary = readGlossary(inputFile);
        Sequence<String> terms = new Sequence1L<>();
        Map<String, String> newGlossary = new Map1L<>();

        while (glossary.size() > 0) {
            Pair<String, String> pair = glossary.removeAny();
            String term = pair.key();
            String def = pair.value();
            terms.add(terms.length(), term);
            newGlossary.add(term, def);
        }
        glossary.transferFrom(newGlossary);
        sort(terms); //sort the terms

        writeIndexPage(terms, outputFolder);
        for (int i = 0; i < terms.length(); i++) {
            String term = terms.entry(i); //add the definition
            String def = glossary.value(term);
            writeTermPage(term, def, terms, outputFolder);
        }

        in.close();
        out.close();
    }

}
