import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * @author Eric Zhou
 *
 */
public class CryptoUtilitiesTest {

    /*
     * Tests of reduceToGCD
     */

    /*
     * testing ReduceToGCD with n is 0, m is 0, boundary case for m
     **/
    @Test
    public void testReduceToGCD_0_0() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(0);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    /*
     * testing ReduceToGCD with n is 30, m is 21, routine test
     **/
    @Test
    public void testReduceToGCD_30_21() {
        NaturalNumber n = new NaturalNumber2(30);
        NaturalNumber nExpected = new NaturalNumber2(3);
        NaturalNumber m = new NaturalNumber2(21);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    /*
     * testing ReduceToGCD with n is 56, m is 98, routine test
     **/
    @Test
    public void testReduceToGCD_56_98() {
        NaturalNumber n = new NaturalNumber2(56);
        NaturalNumber nExpected = new NaturalNumber2(14);
        NaturalNumber m = new NaturalNumber2(98);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    /*
     * testing ReduceToGCD with n is 1, m is 999, large number test
     **/
    @Test
    public void testReduceToGCD_1_999() {
        NaturalNumber n = new NaturalNumber2(1);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber m = new NaturalNumber2(999);
        NaturalNumber mExpected = new NaturalNumber2(0);
        CryptoUtilities.reduceToGCD(n, m);
        assertEquals(nExpected, n);
        assertEquals(mExpected, m);
    }

    /*
     * Tests of isEven
     */

    /*
     * testing isEven with n is 0, boundary case for n
     **/
    @Test
    public void testIsEven_0() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(0);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    /*
     * testing isEven with n is 1, boundary case for n
     **/
    @Test
    public void testIsEven_1() {
        NaturalNumber n = new NaturalNumber2(1);
        NaturalNumber nExpected = new NaturalNumber2(1);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * testing isEven with n is 666666, routine test
     **/
    @Test
    public void testIsEven_666666() {
        NaturalNumber n = new NaturalNumber2(666666);
        NaturalNumber nExpected = new NaturalNumber2(666666);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    /*
     * testing isEven with n is 1234567, large number test
     **/
    @Test
    public void testIsEven_1234567() {
        NaturalNumber n = new NaturalNumber2(1234567);
        NaturalNumber nExpected = new NaturalNumber2(1234567);
        boolean result = CryptoUtilities.isEven(n);
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * Tests of powerMod
     */

    /*
     * testing powerMod with n is 0, p is 0, m is 2, boundary test
     **/
    @Test
    public void testPowerMod_0_0_2() {
        NaturalNumber n = new NaturalNumber2(0);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(0);
        NaturalNumber pExpected = new NaturalNumber2(0);
        NaturalNumber m = new NaturalNumber2(2);
        NaturalNumber mExpected = new NaturalNumber2(2);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    /*
     * testing powerMod with n is 17, p is 18, m is 19, large number test
     **/
    @Test
    public void testPowerMod_17_18_19() {
        NaturalNumber n = new NaturalNumber2(17);
        NaturalNumber nExpected = new NaturalNumber2(1);
        NaturalNumber p = new NaturalNumber2(18);
        NaturalNumber pExpected = new NaturalNumber2(18);
        NaturalNumber m = new NaturalNumber2(19);
        NaturalNumber mExpected = new NaturalNumber2(19);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    /*
     * testing powerMod with n is 2, p is 3, m is 5, routine test
     **/
    @Test
    public void testPowerMod_2_3_5() {
        NaturalNumber n = new NaturalNumber2(2);
        NaturalNumber nExpected = new NaturalNumber2(3);
        NaturalNumber p = new NaturalNumber2(3);
        NaturalNumber pExpected = new NaturalNumber2(3);
        NaturalNumber m = new NaturalNumber2(5);
        NaturalNumber mExpected = new NaturalNumber2(5);
        CryptoUtilities.powerMod(n, p, m);
        assertEquals(nExpected, n);
        assertEquals(pExpected, p);
        assertEquals(mExpected, m);
    }

    /*
     * Test for isWitnessToCompositeness
     */

    /*
     * testing IsWitnessToCompositeness with n is 7, w is 3, routine test
     **/
    @Test
    public void testIsWitnessToCompositeness_3_7() {
        NaturalNumber n = new NaturalNumber2(7);
        NaturalNumber nExpected = new NaturalNumber2(7);
        NaturalNumber w = new NaturalNumber2(3);
        NaturalNumber wExpected = new NaturalNumber2(3);
        boolean isWitness = CryptoUtilities.isWitnessToCompositeness(w, n);
        assertEquals(nExpected, n);
        assertEquals(wExpected, w);
        assertEquals(false, isWitness);
    }

    /*
     * testing IsWitnessToCompositeness with n is 9, w is 2, routine test
     **/
    @Test
    public void testIsWitnessToCompositeness_2_9() {
        NaturalNumber n = new NaturalNumber2(9);
        NaturalNumber nExpected = new NaturalNumber2(9);
        NaturalNumber w = new NaturalNumber2(2);
        NaturalNumber wExpected = new NaturalNumber2(2);
        boolean isWitness = CryptoUtilities.isWitnessToCompositeness(w, n);
        assertEquals(nExpected, n);
        assertEquals(wExpected, w);
        assertEquals(true, isWitness);
    }

    /*
     * testing IsWitnessToCompositeness with n is 101, w is 2, large number test
     **/
    @Test
    public void testIsWitnessToCompositeness_2_101() {
        NaturalNumber n = new NaturalNumber2(101);
        NaturalNumber nExpected = new NaturalNumber2(101);
        NaturalNumber w = new NaturalNumber2(2);
        NaturalNumber wExpected = new NaturalNumber2(2);
        boolean isWitness = CryptoUtilities.isWitnessToCompositeness(w, n);
        assertEquals(nExpected, n);
        assertEquals(wExpected, w);
        assertEquals(false, isWitness);
    }

    /*
     * Tests of isPrime2
     */

    /*
     * testing IsPrime2 with n is 2, boundary test
     **/
    @Test
    public void testIsPrime2_2() {
        NaturalNumber n = new NaturalNumber2(2);
        NaturalNumber nExpected = new NaturalNumber2(2);
        boolean isPrime = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(true, isPrime);
    }

    /*
     * testing IsPrime2 with n is 4, boundary test
     **/
    @Test
    public void testIsPrime2_4() {
        NaturalNumber n = new NaturalNumber2(4);
        NaturalNumber nExpected = new NaturalNumber2(4);
        boolean isPrime = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(false, isPrime);
    }

    /*
     * testing IsPrime2 with n is 97, routine test
     **/
    @Test
    public void testIsPrime2_97() {
        NaturalNumber n = new NaturalNumber2(97);
        NaturalNumber nExpected = new NaturalNumber2(97);
        boolean isPrime = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(true, isPrime);
    }

    /*
     * testing IsPrime2 with n is 4, large number test
     **/
    @Test
    public void testIsPrime2_99999() {
        NaturalNumber n = new NaturalNumber2(99999);
        NaturalNumber nExpected = new NaturalNumber2(99999);
        boolean isPrime = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(false, isPrime);
    }

    /*
     * Tests of generateNextLikelyPrime
     */

    /*
     * testing GenerateNextLikelyPrime with n is 4, boundary test
     **/
    @Test
    public void testGenerateNextLikelyPrime_4() {
        NaturalNumber n = new NaturalNumber2(4);
        NaturalNumber nExpected = new NaturalNumber2(5);
        CryptoUtilities.generateNextLikelyPrime(n);
        boolean isPrime = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(true, isPrime);
    }

    /*
     * testing GenerateNextLikelyPrime with n is 99, routine test
     **/
    @Test
    public void testGenerateNextLikelyPrime_99() {
        NaturalNumber n = new NaturalNumber2(99);
        NaturalNumber nExpected = new NaturalNumber2(101);
        CryptoUtilities.generateNextLikelyPrime(n);
        boolean isPrime = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(true, isPrime);
    }

    /*
     * testing GenerateNextLikelyPrime with n is 99999, large number test
     **/
    @Test
    public void testGenerateNextLikelyPrime_99999() {
        NaturalNumber n = new NaturalNumber2(99999);
        NaturalNumber nExpected = new NaturalNumber2(100003);
        CryptoUtilities.generateNextLikelyPrime(n);
        boolean isPrime = CryptoUtilities.isPrime2(n);
        assertEquals(nExpected, n);
        assertEquals(true, isPrime);
    }

}
