import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * use program to fulfill the pseudoscience and guess the ABCD.
 *
 * @author Eric Zhou
 *
 */
public final class ABCDGuesser1 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private ABCDGuesser1() {
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        boolean get = false;
        double n = -1;
        do {
            out.println("Please enter a positive number: "); //ask for the number
            String s = in.nextLine();
            if (FormatChecker.canParseDouble(s)) { //check whether it is a real number
                n = Double.parseDouble(s);
                if (n > 0) { //check whether it is positive;
                    get = true; //change the signal
                } else {
                    out.println("The number should be positive!");
                }
            } else {
                out.println("The number should be a postive real number!");
            }
        } while (!get);
        return n;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in, SimpleWriter out) {
        boolean get = false;
        double n = -1;
        do {
            out.println("Enter a positive real number and not equal to one");
            String s = in.nextLine();
            if (FormatChecker.canParseDouble(s)) { //check whether it is a real number
                n = Double.parseDouble(s);
                if (n > 0) { //check whether it is positive
                    if (n == 1) { //check whether it equals to one
                        out.println("The number should not be equal to one");
                    } else {
                        get = true; //change the signal
                    }
                } else {
                    out.println("The nuumber should be positive and not equal to one");
                }
            } else {
                out.println("The number should be positive real number");
            }
        } while (!get);
        return n;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        double mu = 0; //initial the data
        double w = 0;
        double x = 0;
        double y = 0;
        double z = 0;

        out.println("Please enter the constant mu you want to check: ");
        mu = getPositiveDouble(in, out); // use method to get data

        out.println("Please enter the w: ");
        w = getPositiveDoubleNotOne(in, out);

        out.println("Please enter the x: ");
        x = getPositiveDoubleNotOne(in, out);

        out.println("Please enter the y: ");
        y = getPositiveDoubleNotOne(in, out);

        out.println("Please enter the z: ");
        z = getPositiveDoubleNotOne(in, out);

        final double[] abcd = { -5, -4, -3, -2, -1, -1.0 / 2, -1.0 / 3, -1.0 / 4, 0,
                1.0 / 4, 1.0 / 3, 1.0 / 2, 1, 2, 3, 4, 5 };

        double[] wPow = new double[abcd.length]; //calculate the power answer
        int i = 0;
        while (i < abcd.length) {
            wPow[i] = Math.pow(w, abcd[i]);
            i++;
        }

        double[] xPow = new double[abcd.length];
        i = 0;
        while (i < abcd.length) {
            xPow[i] = Math.pow(x, abcd[i]);
            i++;
        }

        double[] yPow = new double[abcd.length];
        i = 0;
        while (i < abcd.length) {
            yPow[i] = Math.pow(y, abcd[i]);
            i++;
        }

        double[] zPow = new double[abcd.length];
        i = 0;
        while (i < abcd.length) {
            zPow[i] = Math.pow(z, abcd[i]);
            i++;
        }

        int a = 0;
        int b = 0;
        int c = 0;
        int d = 0;

        int e;
        int r;
        i = 0;
        int k;
        final double maxx = 10000;
        double minError = maxx;
        double error;

        double answer;
        e = 0;
        while (e < abcd.length) { //use loop to check the smallest error
            r = 0;
            while (r < abcd.length) {
                i = 0;
                while (i < abcd.length) {
                    k = 0;
                    while (k < abcd.length) {
                        answer = wPow[e] * xPow[r] * yPow[i] * zPow[k];
                        error = Math.abs(answer - mu);
                        if (error < minError) {
                            minError = error;
                            a = e;
                            b = r;
                            c = i;
                            d = k;
                        }
                        k++;
                    }
                    i++;
                }
                r++;
            }
            e++;
        }

        out.println("a = " + abcd[a]);
        out.println("b = " + abcd[b]);
        out.println("c = " + abcd[c]);
        out.println("d = " + abcd[d]);
        double finalMu = wPow[a] * xPow[b] * yPow[c] * zPow[d];
        out.println("The best approximation is " + finalMu);
        final int hundred = 100;
        double finalError = Math.abs(mu - finalMu) / mu * hundred;

        out.println("The relative error is " + finalError + " %");

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
