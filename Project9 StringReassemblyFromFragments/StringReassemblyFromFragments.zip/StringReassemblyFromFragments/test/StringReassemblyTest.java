import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * @author Eric Zhou
 *
 */
public class StringReassemblyTest {

    /*
     * Tests of combination
     */

    /*
     * testing combination with "hello" and "world", boundary case for overlap
     **/
    @Test
    public void combination_0() {
        String result = StringReassembly.combination("hello", "world", 0);
        assertEquals("helloworld", result);
    }

    /*
     * testing combination with "abc" and "abc", boundary case for overlap
     **/
    @Test
    public void combination_Full() {
        String result = StringReassembly.combination("abc", "abc", 3);
        assertEquals("abc", result);
    }

    /*
     * testing combination with "abcd" and "abcde", boundary case for overlap
     **/
    @Test
    public void combination_WholeWord() {
        String result = StringReassembly.combination("abcd", "abcde", 4);
        assertEquals("abcde", result);
    }

    /*
     * testing combination with "abcd" and "bcde", routine test
     **/
    @Test
    public void combination_AtEnd() {
        String result = StringReassembly.combination("abcd", "bcde", 3);
        assertEquals("abcde", result);
    }

    /*
     * testing combination with "abcd" and "bcde", large number test
     **/
    @Test
    public void combination_longWord() {
        String result = StringReassembly.combination("abcdefgh", "ghijklm", 2);
        assertEquals("abcdefghijklm", result);
    }

    /*
     * Tests of addToSetAvoidingSubstrings
     */

    /*
     * testing addToSetAvoidingSubstrings with "a", "ab" and "abcd", boundary
     * case for set (need to delete the origin elements in the set)
     **/
    @Test
    public void addToSetAvoidingSubstrings_delete() {
        Set<String> expected = new Set1L<>();
        expected.add("abcd");
        Set<String> actual = new Set1L<>();
        actual.add("a");
        actual.add("ab");
        StringReassembly.addToSetAvoidingSubstrings(actual, "abcd");
        assertEquals(expected, actual);
    }

    /*
     * testing addToSetAvoidingSubstrings with "" and "abcd", boundary case for
     * set (the origin set is empty, just add element)
     **/
    @Test
    public void addToSetAvoidingSubstrings_empty() {
        Set<String> expected = new Set1L<>();
        expected.add("abcd");
        Set<String> actual = new Set1L<>();
        StringReassembly.addToSetAvoidingSubstrings(actual, "abcd");
        assertEquals(expected, actual);
    }

    /*
     * testing addToSetAvoidingSubstrings with "xyz"and "abcd", boundary case
     * for set (different string, just add new one)
     **/
    @Test
    public void addToSetAvoidingSubstrings_different() {
        Set<String> expected = new Set1L<>();
        expected.add("abcd");
        expected.add("xyz");
        Set<String> actual = new Set1L<>();
        actual.add("xyz");
        StringReassembly.addToSetAvoidingSubstrings(actual, "abcd");
        assertEquals(expected, actual);
    }

    /*
     * testing addToSetAvoidingSubstrings with "abcdef" and "abcd", boundary
     * case for set (new string is the substring of the original one, do
     * nothing)
     **/
    @Test
    public void addToSetAvoidingSubstrings_keep() {
        Set<String> expected = new Set1L<>();
        expected.add("abcdef");
        Set<String> actual = new Set1L<>();
        actual.add("abcdef");
        StringReassembly.addToSetAvoidingSubstrings(actual, "abcd");
        assertEquals(expected, actual);
    }

    /*
     * Tests of printWithLineSeparators
     */

    /*
     * testing printWithLineSeparators with 3 "~", routine test
     **/
    @Test
    public void printWithLineSeparators_3() {
        String input = "Hello~World~Test";
        final String fileName = "testOutput1.txt";
        SimpleWriter out = new SimpleWriter1L(fileName);
        StringReassembly.printWithLineSeparators(input, out);
        out.close();

        SimpleReader in = new SimpleReader1L(fileName);
        assertEquals("Hello", in.nextLine());
        assertEquals("World", in.nextLine());
        assertEquals("Test", in.nextLine());
        in.close();
    }

    /*
     * testing printWithLineSeparators with no tilde, boundary test
     **/
    @Test
    public void testPrintWithLineSeparators_NoTilde() {
        String input = "This is one line";
        final String fileName = "testOutput2.txt";
        SimpleWriter out = new SimpleWriter1L(fileName);
        StringReassembly.printWithLineSeparators(input, out);
        out.close();

        SimpleReader in = new SimpleReader1L(fileName);
        assertEquals("This is one line", in.nextLine());
        in.close();
    }

    /*
     * testing printWithLineSeparators with tilde at end, boundary test
     **/
    @Test
    public void testPrintWithLineSeparators_TildeAtEnd() {
        String input = "One~Two~";
        final String fileName = "testOutput3.txt";
        SimpleWriter out = new SimpleWriter1L(fileName);
        StringReassembly.printWithLineSeparators(input, out);
        out.close();

        SimpleReader in = new SimpleReader1L(fileName);
        assertEquals("One", in.nextLine());
        assertEquals("Two", in.nextLine());
        in.close();
    }

    /*
     * testing printWithLineSeparators with 7 tilde, large number test
     **/
    @Test
    public void testPrintWithLineSeparators_7() {
        String input = "A~B~C~D~E~F~G~H";
        final String fileName = "testOutput3.txt";
        SimpleWriter out = new SimpleWriter1L(fileName);
        StringReassembly.printWithLineSeparators(input, out);
        out.close();

        SimpleReader in = new SimpleReader1L(fileName);
        assertEquals("A", in.nextLine());
        assertEquals("B", in.nextLine());
        assertEquals("C", in.nextLine());
        assertEquals("D", in.nextLine());
        assertEquals("E", in.nextLine());
        assertEquals("F", in.nextLine());
        assertEquals("G", in.nextLine());
        assertEquals("H", in.nextLine());
        in.close();
    }

    /*
     * Tests of linesFromInput
     */

    /*
     * testing linesFromInput with two substring, routine test
     **/
    @Test
    public void linesFromInput_delate2() {
        final String fileName = "testInputLines.txt";

        SimpleWriter writer = new SimpleWriter1L(fileName);
        writer.println("abc");
        writer.println("abcd");
        writer.println("bcd");
        writer.println("xyz");
        writer.close();

        SimpleReader reader = new SimpleReader1L(fileName);
        Set<String> actual = StringReassembly.linesFromInput(reader);
        reader.close();

        Set<String> expected = new Set1L<>();
        expected.add("abcd");
        expected.add("xyz");

        assertEquals(expected, actual);
    }

    /*
     * testing linesFromInput with no substring, boundary test
     **/
    @Test
    public void testLinesFromInput_NoSubstrings() {
        final String fileName = "testInputNoSubstrings.txt";

        SimpleWriter writer = new SimpleWriter1L(fileName);
        writer.println("cat");
        writer.println("dog");
        writer.println("fish");
        writer.println("bird");
        writer.close();

        SimpleReader reader = new SimpleReader1L(fileName);
        Set<String> actual = StringReassembly.linesFromInput(reader);
        reader.close();

        Set<String> expected = new Set1L<>();
        expected.add("cat");
        expected.add("dog");
        expected.add("fish");
        expected.add("bird");

        assertEquals(expected, actual);

    }

    /*
     * testing linesFromInput with one substring, routine test
     **/
    @Test
    public void testLinesFromInput_OnlyOneSubstringDeleted() {
        final String fileName = "testInputOneSubstring.txt";

        SimpleWriter writer = new SimpleWriter1L(fileName);
        writer.println("hello");
        writer.println("world");
        writer.println("hell");
        writer.close();

        SimpleReader reader = new SimpleReader1L(fileName);
        Set<String> actual = StringReassembly.linesFromInput(reader);
        reader.close();

        Set<String> expected = new Set1L<>();
        expected.add("hello");
        expected.add("world");

        assertEquals(expected, actual);
    }

}
