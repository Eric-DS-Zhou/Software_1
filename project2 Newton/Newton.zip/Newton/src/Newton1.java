import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * To calculate the square root.
 *
 * @author Eric Zhou.
 *
 */
public final class Newton1 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Newton1() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param x
     *            positive number to compute square root of
     * @return estimate of square root
     */
    private static double sqrt(double x) {
        final double ep = 0.0001; //set the error
        double r = x;
        while ((Math.abs(r * r - x) / x) > ep * ep) { //calculate the square root
            r = (r + (x / r)) / 2;
        }
        return r;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        do {
            out.println("Enter a postive number: "); //ask for the number
            out.println(sqrt(in.nextDouble()));
            out.println("Do u want to continue? Press 'y' or anything else to stop");
        } while (in.nextLine().equals("y")); //check whether the user want to continue
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
