import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * To calculate the square root.
 *
 * @author Eric Zhou.
 *
 */
public final class Newton4 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Newton4() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param x
     *            positive number and zero to compute square root of
     * @param epInput
     *            the relevant error and no more than 0.01%
     * @return estimate of square root
     */
    private static double sqrt(double x, double epInput) {
        final double ep = epInput; //set the error
        if (x == 0) { //solve the problem that x equals to zero
            return x;
        } else {
            double r = x;
            while ((Math.abs(r * r - x) / x) > ep * ep) { //calculate the square root
                r = (r + (x / r)) / 2;
            }
            return r;
        }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        out.println("Enter a eplison: "); // ask for the error
        double epInput = in.nextDouble();
        double x = 0;
        while (x >= 0) { // stop when x is smaller than zero
            out.println("Enter a non-negative number: ");
            x = in.nextDouble();
            out.println(sqrt(x, epInput));
        }

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
