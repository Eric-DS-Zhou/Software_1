import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.Reporter;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program to evaluate XMLTree expressions of {@code int}.
 *
 * @author Eric Zhou
 *
 */
public final class XMLTreeNNExpressionEvaluator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeNNExpressionEvaluator() {
    }

    /**
     * Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires * [exp is a subtree of a well-formed XML arithmetic expression]
     *           and [the label of the root of exp is not "expression"]
     *
     * @ensures evaluate = [the value of the expression]
     */
    private static NaturalNumber evaluate(XMLTree exp) {
        assert exp != null : "Violation of: exp is not null";

        NaturalNumber result;

        if (exp.label().equals("number")) { //decide the end of recursion
            result = new NaturalNumber1L(Integer.parseInt(exp.attributeValue("value")));
        } else {
            NaturalNumber left = evaluate(exp.child(0)); //recursion
            NaturalNumber right = evaluate(exp.child(1));
            result = new NaturalNumber1L(left);
            String op = exp.label(); // check the operator

            if (op.equals("plus")) {
                result.add(right);
            } else if (op.equals("minus")) {
                if (result.compareTo(right) < 0) { //assert the number should be positive
                    Reporter.fatalErrorToConsole("NaturalNumber should be positive");
                }
                result.subtract(right);
            } else if (op.equals("times")) {
                result.multiply(right);
            } else if (op.equals("divide")) {
                if (right.isZero()) { // assert that cannot divide zero
                    Reporter.fatalErrorToConsole("cannot divide by zero");
                }
                result.divide(right);
            }
        }
        return result;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            out.println(evaluate(exp.child(0)));
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}
